// C++ code to implement computation of pi
#include <bits/stdc++.h>
#include <stdio.h>
#include <math.h>
#include <mpi.h>
using namespace std;
 
// Function to calculate PI
long double calcPI(long double PI, long double n, long double sign, unsigned long start, unsigned long end )
{
    // Add for (iterations) 
    for (unsigned long int i = start; i <= end; i++) {
        PI = PI + (sign * (4 / ((n) * (n + 1) * (n + 2))));
        // Add and sub
        // alt sequences
        sign = sign * (-1);
        // Increment by 2 according to Nilkantha’s formula
        n += 2;
    }
 
    // Return the value of Pi
    return PI;
}
 
// main
int main(int argc, char** argv)
{
    // Initialise variables, require/accept passed-in value 
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    printf("Hello from rank %d of %d\n", rank, size);

    std::chrono::steady_clock::time_point start, end;
    if (argc==1)
    {
      if (rank == 0) {
	printf("You must pass a single numeric value\n");
	printf("the value should be 100M or higher\n");
      }
      MPI_Finalize();
      return -1;
    }

    if (rank == 0) {
        start = std::chrono::steady_clock::now();
    }


    long double iterations = std::stod(argv[1]); // set to passed-in numeric value
    unsigned long chunk = iterations / size;
    unsigned long start_idx = rank * chunk;
    unsigned long end_idx = (rank == size - 1) ? iterations : start_idx + chunk - 1;

    long double n = 2 + start_idx * 2, sign = ((start_idx / 2) % 2 == 0) ? 1.0 : -1.0;   
    long double cPI = calcPI(0.0L, n, sign, start_idx, end_idx);

    MPI_Win win;
    long double totalPI = 0.0;

    MPI_Win_create(&totalPI, rank == 0 ? sizeof(long double) : 0, sizeof(long double), MPI_INFO_NULL, MPI_COMM_WORLD, &win);

    MPI_Win_lock_all(0, win);
    MPI_Accumulate(&cPI, 1, MPI_LONG_DOUBLE, 0, 0, 1, MPI_LONG_DOUBLE, MPI_SUM, win);
    MPI_Win_flush_all(win);
    MPI_Win_unlock_all(win);

    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0) {
	end = std::chrono::steady_clock::now();
        totalPI += 3.0;
	const long double PI25DT = 3.141592653589793238462643383; // set test value for error
	printf("PI is approx %.50Lf, Error is %.50Lf\n", totalPI, fabsl(totalPI - PI25DT));
    	auto diff = end - start; // compute time
    	std::cout << std::chrono::duration<double, std::milli>(diff).count() << " Runtime ms" << std::endl;
    }
    MPI_Win_free(&win);
    MPI_Finalize();
    return 0;
}


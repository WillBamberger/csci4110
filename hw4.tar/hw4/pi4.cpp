// C++ code to implement computation of pi using BBP formula
#include <bits/stdc++.h>
#include <stdio.h>
#include <math.h>
#include <mpi.h>
using namespace std;
 
// Function to calculate PI using BBP formula
long double calcPI(unsigned long start, unsigned long end)
{
    long double PI = 0.0;
    for (unsigned long int k = start; k <= end; k++) {
        PI += (1.0 / pow(16, k)) * (
            4.0 / (8 * k + 1) -
            2.0 / (8 * k + 4) -
            1.0 / (8 * k + 5) -
            1.0 / (8 * k + 6));
    }
    return PI;
}
 
// main
int main(int argc, char** argv)
{
    // Initialise variables, require/accept passed-in value 
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    printf("Hello from rank %d of %d\n", rank, size);

    std::chrono::steady_clock::time_point start, end;
    if (argc==1)
    {
      if (rank == 0) {
        printf("You must pass a single numeric value\n");
        printf("the value should be 100M or higher\n");
      }
      MPI_Finalize();
      return -1;
    }

    if (rank == 0) {
        start = std::chrono::steady_clock::now();
    }

    unsigned long iterations = std::stoul(argv[1]); // set to passed-in numeric value
    unsigned long chunk = iterations / size;
    unsigned long start_idx = rank * chunk;
    unsigned long end_idx = (rank == size - 1) ? iterations : start_idx + chunk - 1;

    long double cPI = calcPI(start_idx, end_idx);

    long double totalPI = 0.0;
    MPI_Reduce(&cPI, &totalPI, 1, MPI_LONG_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        end = std::chrono::steady_clock::now();
        const long double PI25DT = 3.141592653589793238462643383; // set test value for error
        printf("PI is approx %.50Lf, Error is %.50Lf\n", totalPI, fabsl(totalPI - PI25DT));
        auto diff = end - start; // compute time
        std::cout << std::chrono::duration<double, std::milli>(diff).count() << " Runtime ms" << std::endl;
    }
    MPI_Finalize();
    return 0;
}

